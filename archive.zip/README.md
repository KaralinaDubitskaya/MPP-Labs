# MPP-Labs
Modern Programming Platforms, BSUIR 2018
